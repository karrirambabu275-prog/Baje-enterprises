# BJ Enterprises — React (Vite) app

This repo contains the BJ Enterprises demo React application.

Quick start (local)
1. Install dependencies:
   npm install

2. Run dev server:
   npm run dev
   Open http://localhost:5173

3. Build for production:
   npm run build

4. Preview production build locally:
   npm run preview

Notes
- The project uses HashRouter so client-side routing works on static hosts (Netlify, GitHub Pages, Vercel) without extra server config.
- Tailwind CDN is included in index.html for quick styling. For production, install and configure Tailwind properly or replace with your CSS.
- Products and cart are persisted in localStorage (keys: `bj_products`, `bj_cart`, `bj_last_order`).

Deploy options
- Vercel (recommended for quick deploy):
  1. Create a Vercel account and connect your GitHub repo.
  2. Build command: `npm run build`
     Output directory: `dist`
  3. Import & deploy — Vercel will build and host automatically.

- Netlify:
  1. Create a Netlify site and connect the GitHub repo.
  2. Build command: `npm run build`
     Publish directory: `dist`
  3. netlify.toml is included to ensure SPA redirects.

- GitHub Pages:
  1. Build: `npm run build`.
  2. Push the contents of `dist/` to a `gh-pages` branch (or use a GitHub Action).
  3. Because HashRouter is used and vite.base is './', the site will work under `/repo/` path.

If you want, I can:
- Create the GitHub repo and push these files for you (tell me owner/name).
- Add a GitHub Action to auto-deploy to GitHub Pages or Netlify.
- Replace Tailwind CDN with a proper Tailwind setup and build step.

Which next step do you want me to do for you?